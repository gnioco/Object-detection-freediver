# Obj19512 > 2023-10-21 3:57pm
https://universe.roboflow.com/freediv19511/obj19512

Provided by a Roboflow user
License: CC BY 4.0

