# Obj19511 > 2023-10-18 9:54am
https://universe.roboflow.com/freediv19511/obj19511

Provided by a Roboflow user
License: CC BY 4.0

